# import cv2
# import os

# def load_image(image_path):
#     """Load an image from the specified path."""
#     return cv2.imread(image_path)

# def convert_to_grayscale(image):
#     """Convert an image to grayscale."""
#     return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# def apply_threshold(image, threshold_value=127):
#     """Apply binary thresholding to an image."""
#     _, thresh_image = cv2.threshold(image, threshold_value, 255, cv2.THRESH_BINARY)
#     return thresh_image

# def save_image(image, output_path):
#     """Save an image to the specified path."""
#     cv2.imwrite(output_path, image)

# src/app.py

from image_processing import load_image, convert_to_grayscale, apply_threshold, save_image
from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')  # Ensure you have an index.html in a templates folder

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return "No file part"
    
    file = request.files['file']
    if file.filename == '':
        return "No selected file"
    
    # Process the uploaded image
    image = load_image(file)
    gray_image = convert_to_grayscale(image)
    thresholded_image = apply_threshold(gray_image)
    
    # Save the processed image
    save_image(thresholded_image, 'output.png')  # Save to a desired location

    return "Image processed and saved!"

if __name__ == '__main__':
    app.run(debug=True)