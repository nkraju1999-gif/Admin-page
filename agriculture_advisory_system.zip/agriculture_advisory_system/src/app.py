# import os
# import sys
# from .image_processing import load_image, convert_to_grayscale, apply_threshold, save_image
# from .model import train_model, save_model, load_model
# from .utils import get_image_paths

# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# def main():
#     # Load images
#     image_paths = get_image_paths('data/raw/')
#     for image_path in image_paths:
#         image = load_image(image_path)
#         gray_image = convert_to_grayscale(image)
#         thresh_image = apply_threshold(gray_image)

#         # Save processed images
#         save_image(thresh_image, f'data/processed/{os.path.basename(image_path)}')

#     # Example of training a model (assuming X and y are prepared)
#     # model = train_model(X, y)
#     # save_model(model, 'models/model.pkl')

# if __name__ == "__main__":
#     main()
# # Continue with the main application logic

# src/app.py

# src/app.py

from src.image_processing import load_image, convert_to_grayscale, apply_threshold, save_image
from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')  # Ensure you have an index.html in a templates folder

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return "No file part"
    
    file = request.files['file']
    if file.filename == '':
        return "No selected file"
    
    # Process the uploaded image
    image = load_image(file)
    gray_image = convert_to_grayscale(image)
    thresholded_image = apply_threshold(gray_image)
    
    # Save the processed image
    save_image(thresholded_image, 'output.png')  # Save to a desired location

    return "Image processed and saved!"

if __name__ == '__main__':
    app.run(debug=True)