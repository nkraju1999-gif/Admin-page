import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

def train_model(X, y):
    """Train a Random Forest model."""
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    model = RandomForestClassifier()
    model.fit(X_train, y_train)
    return model

def save_model(model, model_path):
    """Save the trained model to a file."""
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)

def load_model(model_path):
    """Load a trained model from a file."""
    with open(model_path, 'rb') as f:
        return pickle.load(f)