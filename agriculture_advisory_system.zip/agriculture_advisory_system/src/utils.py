import os
import cv2

def get_image_paths(data_dir):
    """Get a list of image paths from the specified directory."""
    return [os.path.join(data_dir, f) for f in os.listdir(data_dir) if f.endswith(('.png', '.jpg', '.jpeg'))]